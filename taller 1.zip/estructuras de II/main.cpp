#include<iostream>
using namespace std;
void tabla(int);
int main () {
	
	int a,j ;
	printf ("ingrese el numero de la tabla que desea multiplicar  \n");
	scanf ("%d",a);
	for (int i = 1 ; i <= 20 ; i++ ){
		for(j=1; j<=20; j++){
			
		}
		printf ("%d * %d = %d \n  ",a,j,a*j);
	}
	
	
	return 0;
}

