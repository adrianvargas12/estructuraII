#include<iostream>
using namespace std;

int main () {
	
	int a,j ;
	printf ("ingrese el numero de la tabla que desea multiplicar  \n");
	scanf ("%d",&a);
	
		for(j=0; j<=20; j++){
			
		
		printf ("%d * %d = %d \n  ",a,j,a*j);
	
}
	
	return 0;
}

