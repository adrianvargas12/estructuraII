#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	
	return 0;
}

