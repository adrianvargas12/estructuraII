#include <iostream>
using namespace std;

int main() {
	
	
		
		int a,i;
		a=0;
		for(i=1; i<=100; i++)
		{
			a=a+i;
		
	
			printf("%d \n",a);
		
		}
		
	
	return 0;
}

