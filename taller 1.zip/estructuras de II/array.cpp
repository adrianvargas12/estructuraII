#include <iostream>
using namespace std;

int main(int argc, char *argv[]) {
	float vector[4]={32.583,11.239,45.781,22.237};
	
	
	for (int i=0; i<4; i++ ){
		printf("%f\n" ,vector[i] );
		
	}
	
	return 0;
}

